const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());

// --- MongoDB Connection ---
const MONGO_URI = 'mongodb://localhost:27017/ballersconnect';
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

// --- User Schema ---
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  bio: String,
  interests: String,
  dob: String,
  avatar: String,
  status: { type: String, default: 'Online' }
});
const User = mongoose.model('User', userSchema);

// --- Admin Schema ---
const adminSchema = new mongoose.Schema({
  email: { type: String, unique: true },
  password: String
});
const Admin = mongoose.model('Admin', adminSchema);

// --- Register ---
app.post('/api/register', async (req, res) => {
  try {
    const { name, email, password, bio, interests, dob, avatar } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hash, bio, interests, dob, avatar });
    await user.save();
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// --- Login ---
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'User not found' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ error: 'Invalid password' });
    // Create JWT
    const token = jwt.sign({ id: user._id }, 'SECRET_KEY');
    res.json({ token, user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// --- Admin Login ---
app.post('/api/admin/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(400).json({ error: 'Admin not found' });
    const match = await bcrypt.compare(password, admin.password);
    if (!match) return res.status(400).json({ error: 'Invalid password' });
    // Create JWT for admin
    const token = jwt.sign({ id: admin._id, isAdmin: true }, 'SECRET_KEY');
    res.json({ token, admin: { email: admin.email, id: admin._id } });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// --- Admin Auth Middleware ---
function adminAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  jwt.verify(token, 'SECRET_KEY', (err, decoded) => {
    if (err || !decoded.isAdmin) return res.status(403).json({ error: 'Invalid or unauthorized token' });
    req.adminId = decoded.id;
    next();
  });
}

// --- Get Profile ---
app.get('/api/profile/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// --- Get All Users (for admin panel) ---
app.get('/api/users', adminAuth, async (req, res) => {
  try {
    const users = await User.find({}, '-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Ban User (set status to Banned) ---
app.post('/api/users/:id/ban', adminAuth, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.id, { status: 'Banned' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Create New Admin ---
app.post('/api/admins', adminAuth, async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    const hash = await bcrypt.hash(password, 10);
    const admin = new Admin({ email, password: hash });
    await admin.save();
    res.json({ success: true });
  } catch (err) {
    if (err.code === 11000) {
      res.status(400).json({ error: 'Admin email already exists' });
    } else {
      res.status(500).json({ error: err.message });
    }
  }
});

// --- Start Server ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server running on port', PORT));
