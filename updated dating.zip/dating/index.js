// Splash screen heartbeat logic
window.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        var splash = document.getElementById('splash');
        var authApp = document.getElementById('authApp');
        if (splash) splash.style.display = 'none';
        if (authApp) authApp.style.display = 'block';
    }, 1800);
});

// Auth toggle logic
const showLogin = document.getElementById('showLogin');
const showSignup = document.getElementById('showSignup');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
showLogin.onclick = function() {
    showLogin.classList.add('active');
    showSignup.classList.remove('active');
    loginForm.style.display = '';
    signupForm.style.display = 'none';
};
showSignup.onclick = function() {
    showSignup.classList.add('active');
    showLogin.classList.remove('active');
    loginForm.style.display = 'none';
    signupForm.style.display = '';
};

// Profile photo preview logic
const signupPhoto = document.getElementById('signupPhoto');
const signupPhotoPreview = document.getElementById('signupPhotoPreview');
let uploadedPhotoFile = null;
signupPhoto.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        uploadedPhotoFile = file;
        const reader = new FileReader();
        reader.onload = function(evt) {
            signupPhotoPreview.src = evt.target.result;
            signupPhotoPreview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
});

// --- Signup with custom backend ---
signupForm.onsubmit = async function(e) {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('signupConfirmPassword').value;
    const bio = document.getElementById('signupBio').value;
    const interests = document.getElementById('signupInterests').value;
    const year = parseInt(document.getElementById('dobYear').value);
    const month = parseInt(document.getElementById('dobMonth').value);
    const day = parseInt(document.getElementById('dobDay').value);
    const dob = new Date(year, month - 1, day);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
        age--;
    }
    if (age < 20) {
        alert('You are not eligible. You must be at least 20 years old.');
        return;
    }
    if (!email.match(/^[^@\s]+@[^@\s]+\.[^@\s]+$/)) {
        alert('Please enter a valid email address.');
        return;
    }
    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }
    try {
        const res = await fetch('http://localhost:5000/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name, email, password, bio, interests, dob: dob.toISOString().split('T')[0], avatar: ''
            })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Signup failed');
        alert('Signup successful! Please log in.');
        showLogin.classList.add('active');
        showSignup.classList.remove('active');
        loginForm.style.display = '';
        signupForm.style.display = 'none';
    } catch (err) {
        alert('Signup failed: ' + err.message);
    }
};

// --- Login with custom backend ---
loginForm.onsubmit = async function(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    try {
        const res = await fetch('http://localhost:5000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Login failed');
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        window.location.href = 'home.html';
    } catch (err) {
        alert('Login failed: ' + err.message);
    }
};

// Populate DOB dropdowns
(function() {
    const yearSelect = document.getElementById('dobYear');
    const monthSelect = document.getElementById('dobMonth');
    const daySelect = document.getElementById('dobDay');
    if (yearSelect && monthSelect && daySelect) {
        const now = new Date();
        const thisYear = now.getFullYear();
        for (let y = thisYear; y >= 1900; y--) {
            const opt = document.createElement('option');
            opt.value = y;
            opt.textContent = y;
            yearSelect.appendChild(opt);
        }
        for (let m = 1; m <= 12; m++) {
            const opt = document.createElement('option');
            opt.value = m;
            opt.textContent = m;
            monthSelect.appendChild(opt);
        }
        function updateDays() {
            const year = parseInt(yearSelect.value);
            const month = parseInt(monthSelect.value);
            const daysInMonth = new Date(year, month, 0).getDate();
            daySelect.innerHTML = '';
            for (let d = 1; d <= daysInMonth; d++) {
                const opt = document.createElement('option');
                opt.value = d;
                opt.textContent = d;
                daySelect.appendChild(opt);
            }
        }
        yearSelect.onchange = monthSelect.onchange = updateDays;
        yearSelect.value = thisYear - 20;
        monthSelect.value = 1;
        updateDays();
    }
})();

// Logout feature
const logoutBtn = document.getElementById('logoutBtn');
logoutBtn.onclick = function() {
    document.getElementById('mainApp').style.display = 'none';
    document.getElementById('splash').style.display = 'flex';
    setTimeout(function() {
        document.getElementById('splash').style.display = 'none';
        document.getElementById('authApp').style.display = 'block';
    }, 1800);
};

// Render profiles (excluding current user)
const profilesDiv = document.getElementById('profiles');
function renderProfiles() {
    profilesDiv.innerHTML = '';
    users.filter(u => u !== currentUser).forEach((profile, idx) => {
        const card = document.createElement('div');
        card.className = 'profile-card';
        card.innerHTML = `
            <h3>${profile.name}</h3>
            <p>${profile.bio}</p>
            <p><strong>Interests:</strong> ${profile.interests}</p>
            <p><strong>Phone:</strong> ${profile.phone || ''}</p>
            <div class="actions">
                <button class="like" onclick="alert('You liked ${profile.name}!')">Like</button>
                <button onclick="alert('You skipped ${profile.name}.')">Skip</button>
            </div>
        `;
        profilesDiv.appendChild(card);
    });
}

// Forgot password logic
const forgotPasswordLink = document.getElementById('forgotPasswordLink');
forgotPasswordLink.onclick = async function(e) {
    e.preventDefault();
    const email = prompt('Enter your email address to reset your password:');
    if (!email) return;
    try {
        await firebase.auth().sendPasswordResetEmail(email);
        alert('Password reset email sent! Please check your inbox.');
    } catch (err) {
        alert('Error: ' + err.message);
    }
};

// Show/hide password toggles (now using <span> icons at the input corner)
function setupPasswordToggles() {
    const toggleLogin = document.getElementById('toggleLoginPassword');
    const loginInput = document.getElementById('loginPassword');
    if (toggleLogin && loginInput) {
        toggleLogin.onclick = function() {
            loginInput.type = loginInput.type === 'password' ? 'text' : 'password';
            toggleLogin.textContent = loginInput.type === 'password' ? '👁️' : '🙈';
        };
    }
    const toggleSignup = document.getElementById('toggleSignupPassword');
    const signupInput = document.getElementById('signupPassword');
    if (toggleSignup && signupInput) {
        toggleSignup.onclick = function() {
            signupInput.type = signupInput.type === 'password' ? 'text' : 'password';
            toggleSignup.textContent = signupInput.type === 'password' ? '👁️' : '🙈';
        };
    }
    const toggleSignupConfirm = document.getElementById('toggleSignupConfirmPassword');
    const signupConfirmInput = document.getElementById('signupConfirmPassword');
    if (toggleSignupConfirm && signupConfirmInput) {
        toggleSignupConfirm.onclick = function() {
            signupConfirmInput.type = signupConfirmInput.type === 'password' ? 'text' : 'password';
            toggleSignupConfirm.textContent = signupConfirmInput.type === 'password' ? '👁️' : '🙈';
        };
    }
}
window.addEventListener('DOMContentLoaded', setupPasswordToggles);
